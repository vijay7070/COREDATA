//
//  TABLEVIEWCONTROLLER.h
//  COREDATA RAJ
//
//  Created by Student P_02 on 15/07/17.
//  Copyright © 2017 Felix ITs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TABLEVIEWCONTROLLER : UIViewController<UITableViewDelegate,UITableViewDataSource>{
    NSArray *array;
}
@property (weak, nonatomic) IBOutlet UITableView *tblvw;

@end
