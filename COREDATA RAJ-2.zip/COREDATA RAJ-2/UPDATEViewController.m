//
//  UPDATEViewController.m
//  COREDATA RAJ
//
//  Created by Student P_02 on 16/07/17.
//  Copyright © 2017 Felix ITs. All rights reserved.
//

#import "UPDATEViewController.h"
#import "AppDelegate.h"
#import "TABLEVIEWCONTROLLER.h"
#import "ViewController.h"
#import <SDWebImage/UIImageView+WebCache.h>
@interface UPDATEViewController (){
    NSManagedObjectContext *context;
    BOOL isRemoveTrue, isImageUploaded;
}

@end

@implementation UPDATEViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    isRemoveTrue = false;
    isImageUploaded = false;
    AppDelegate *ud=(AppDelegate *)[UIApplication sharedApplication].delegate;
    NSLog(@"%@",ud.persistentContainer.viewContext);
    context=ud.persistentContainer.viewContext;
    
  //  NSManagedObject *obj = [array objectAtIndex:indexPath.row];
    NSArray *arraypath =NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
         NSString *strPath = arraypath[0];
    NSString *strImgName = [_upOBJ valueForKey:@"imgname"];
    NSString *strFullPAth = [strPath stringByAppendingPathComponent:strImgName];
    
    [_upimgvw sd_setImageWithURL:[NSURL fileURLWithPath:strFullPAth] placeholderImage:[UIImage imageNamed:@"images.png"]];
    _upname.text=[_upOBJ valueForKey:@"name"];
    _upaddress.text=[_upOBJ valueForKey:@"address"];
    NSError *error;
    [context save:&error];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    isRemoveTrue = false;
    isImageUploaded = true;
    NSLog(@"%@",info);
   
    UIImage *imge = info[UIImagePickerControllerEditedImage];
    _upimgvw.image=imge;
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

- (IBAction)updatebutton:(id)sender {
    if (isRemoveTrue) {
        [_upOBJ setValue:@"" forKey:@"imgname"];
    }else if (isImageUploaded){
        NSArray *array =NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *strPath = array[0];
        NSData *data = UIImageJPEGRepresentation(_upimgvw.image, 1);
        NSString *strName =[self uuid];
        [data writeToFile:[strPath stringByAppendingPathComponent:strName] atomically:YES];
        [_upOBJ setValue:strName forKey:@"imgname"];
    }
    [_upOBJ setValue:_upname.text forKey:@"name"];
    [_upOBJ setValue:_upaddress.text forKey:@"address"];
    NSError *error;
    [context save:&error];
    UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"Updated Successfully" message:error.localizedDescription preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action=[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        [self dismissViewControllerAnimated:YES completion:nil];
        [self.navigationController popViewControllerAnimated:YES];

    }];
    [alert addAction:action];
    [self presentViewController:alert animated:YES completion:nil];

    }
                           
-(NSString *)uuid
{
    CFUUIDRef uuidRef = CFUUIDCreate(NULL);
    CFStringRef uuidStringRef = CFUUIDCreateString(NULL, uuidRef);
    CFRelease(uuidRef);
    NSString *strName = [NSString stringWithFormat:@"%@.png", (__bridge_transfer NSString *)uuidStringRef];
    return strName;
}
- (IBAction)uploadphoto:(id)sender {
    UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"BROWSE" message:@"CHOOSE THE OPTION" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action1=[UIAlertAction actionWithTitle:@"CAMERA" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        [self dismissViewControllerAnimated:YES completion:nil];
        UIImagePickerController *picker=[[UIImagePickerController alloc]init];
        picker.delegate=self;
        picker.allowsEditing=YES;
        picker.sourceType=UIImagePickerControllerSourceTypeCamera;
        [self presentViewController:picker animated:YES completion:nil];
    }];
    UIAlertAction *action2=[UIAlertAction actionWithTitle:@"GALLERY" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        [self dismissViewControllerAnimated:YES completion:nil];
        UIImagePickerController *picker=[[UIImagePickerController alloc]init];
        picker.delegate=self;
        picker.allowsEditing=YES;
        picker.sourceType=UIImagePickerControllerSourceTypePhotoLibrary;
        [self presentViewController:picker animated:YES completion:nil];
    }];
    UIAlertAction *action3=[UIAlertAction actionWithTitle:@"CANCEL" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        [self dismissViewControllerAnimated:YES completion:nil];
    }];
    
    [alert addAction:action1];
    [alert addAction:action2];
    [alert addAction:action3];
    [self presentViewController:alert animated:YES completion:nil];
    
    

}

- (IBAction)REMOVEIMG:(id)sender {
    NSArray *arraypath =NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *strPath = arraypath[0];
    NSString *strImgName = [_upOBJ valueForKey:@"imgname"];
    NSString *strFullPAth = [strPath stringByAppendingPathComponent:strImgName];
    NSFileManager *file = [NSFileManager defaultManager];
    [file removeItemAtPath:strFullPAth error:nil];
    isRemoveTrue=YES;
    _upimgvw.image = [UIImage imageNamed:@"images.png"];
    
}
@end
