//
//  SearchViewController.m
//  COREDATA RAJ
//
//  Created by Student P_02 on 16/07/17.
//  Copyright © 2017 Felix ITs. All rights reserved.
//

#import "SearchViewController.h"
#import "SearchTableViewCell.h"
#import "AppDelegate.h"
#import "ViewController.h"
#import "UPDATEViewController.h"
#import "SearchTableViewCell.h"
#import "TABLEVIEWCONTROLLER.h"
#import <SDWebImage/UIImageView+WebCache.h>
@interface SearchViewController (){
    NSManagedObjectContext *context;
}

@end

@implementation SearchViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    // _tblvw.delegate=self;
    //_tblvw.dataSource=self;
    AppDelegate *ud=(AppDelegate *)[UIApplication sharedApplication].delegate;
    NSLog(@"%@",ud.persistentContainer.viewContext);
    context=ud.persistentContainer.viewContext;
    _searchbar.delegate=self;
    _searchtblvw.delegate=self;
    _searchtblvw.dataSource=self;
}
-(void)viewWillAppear:(BOOL)animated{
    NSFetchRequest *fetch=[NSFetchRequest fetchRequestWithEntityName:@"Person"];
    NSError *error;
    array=[context executeFetchRequest:fetch error:&error];
    if (error) {
        NSLog(@"%@",error.localizedDescription);
    }
    else{
        _searchtblvw.delegate=self;
        _searchtblvw.dataSource=self;
        [_searchtblvw reloadData];
    }
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return array.count;
    
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *string=@"SearchTableViewCell";
    SearchTableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:string];
    if(cell==nil){
        cell=[[SearchTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:string];
        
    }
    NSManagedObject *obj = [array objectAtIndex:indexPath.row];
    NSArray *arraypath =NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *strPath = arraypath[0];
    NSString *strImgName = [obj valueForKey:@"imgname"];
    NSString *strFullPAth = [strPath stringByAppendingPathComponent:strImgName];
    [cell.searchimage sd_setImageWithURL:[NSURL fileURLWithPath:strFullPAth] placeholderImage:[UIImage imageNamed:@"images.png"]];
    cell.searchname.text=[obj valueForKey:@"name"];
    cell.searchaddress.text=[obj valueForKey:@"address"];
  
    return cell;
    
}
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        NSMutableArray *muarray=[[NSMutableArray alloc]init];
        muarray=[array mutableCopy];
        NSManagedObject *obj=[array objectAtIndex:indexPath.row];
        [context deleteObject:obj];
        [context save:nil];
        [muarray removeObjectAtIndex:indexPath.row];
        array =[muarray copy];
        [_searchtblvw reloadData];
    }
}
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return YES - we will be able to delete all rows
    return YES;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSManagedObject *obj=[array objectAtIndex:indexPath.row];
    UPDATEViewController *up=[self.storyboard instantiateViewControllerWithIdentifier:@"UPDATEViewController"];
    up.upOBJ=obj;
    [self.navigationController pushViewController:up animated:YES];
    
    
    
}
- (BOOL)searchBar:(UISearchBar *)searchBar shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text NS_AVAILABLE_IOS(3_0){
    
    NSFetchRequest *fetch = [[NSFetchRequest alloc]initWithEntityName:@"Person"];
    NSPredicate *pred = [NSPredicate predicateWithFormat:[NSString stringWithFormat:@"name BEGINSWITH '%@' ",searchBar.text]];
    
    fetch.predicate = pred;
    array = [context executeFetchRequest:fetch error:nil];
    
    [_searchtblvw reloadData];
    
    
    return YES;
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{
    
    
    NSFetchRequest *fetch = [[NSFetchRequest alloc]initWithEntityName:@"Person"];
    NSPredicate *pred = [NSPredicate predicateWithFormat:[NSString stringWithFormat:@"name BEGINSWITH '%@' ",searchBar.text]];
    
    fetch.predicate = pred;
    array = [context executeFetchRequest:fetch error:nil];
   
    [_searchtblvw reloadData];
}
@end

