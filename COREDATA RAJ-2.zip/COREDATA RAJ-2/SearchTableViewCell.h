//
//  SearchTableViewCell.h
//  COREDATA RAJ
//
//  Created by Student P_02 on 16/07/17.
//  Copyright © 2017 Felix ITs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *searchname;
@property (strong, nonatomic) IBOutlet UIImageView *searchimage;
@property (weak, nonatomic) IBOutlet UILabel *searchaddress;
@end
