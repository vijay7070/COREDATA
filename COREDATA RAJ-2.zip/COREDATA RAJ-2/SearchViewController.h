//
//  SearchViewController.h
//  COREDATA RAJ
//
//  Created by Student P_02 on 16/07/17.
//  Copyright © 2017 Felix ITs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchViewController : UIViewController<UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate>{
    NSArray *array;
}
@property (weak, nonatomic) IBOutlet UITableView *searchtblvw;


@property (weak, nonatomic) IBOutlet UISearchBar *searchbar;

@end
