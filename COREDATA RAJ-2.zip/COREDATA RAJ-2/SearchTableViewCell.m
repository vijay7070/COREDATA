//
//  SearchTableViewCell.m
//  COREDATA RAJ
//
//  Created by Student P_02 on 16/07/17.
//  Copyright © 2017 Felix ITs. All rights reserved.
//

#import "SearchTableViewCell.h"

@implementation SearchTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
