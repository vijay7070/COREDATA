//
//  UPDATEViewController.h
//  COREDATA RAJ
//
//  Created by Student P_02 on 16/07/17.
//  Copyright © 2017 Felix ITs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
@interface UPDATEViewController : UIViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate>
@property (weak, nonatomic) IBOutlet UITextField *upname;
- (IBAction)uploadphoto:(id)sender;
- (IBAction)REMOVEIMG:(id)sender;
@property (strong, nonatomic) IBOutlet UIImageView *upimgvw;

@property (weak, nonatomic) IBOutlet UITextField *upaddress;
- (IBAction)updatebutton:(id)sender;
@property(nonatomic,strong) NSManagedObject *upOBJ;
@end
