//
//  CoredataViewCell.h
//  COREDATA RAJ
//
//  Created by Student P_02 on 15/07/17.
//  Copyright © 2017 Felix ITs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CoredataViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *showname;
@property (weak, nonatomic) IBOutlet UILabel *showaddress;
@property (strong, nonatomic) IBOutlet UIImageView *cellimgvw;

@end
