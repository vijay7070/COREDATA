//
//  TABLEVIEWCONTROLLER.m
//  COREDATA RAJ
//
//  Created by Student P_02 on 15/07/17.
//  Copyright © 2017 Felix ITs. All rights reserved.
//

#import "TABLEVIEWCONTROLLER.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import "CoredataViewCell.h"
#import "AppDelegate.h"
#import "ViewController.h"
#import "UPDATEViewController.h"
@interface TABLEVIEWCONTROLLER (){
    NSManagedObjectContext *context;
}

@end

@implementation TABLEVIEWCONTROLLER

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
   // _tblvw.delegate=self;
    //_tblvw.dataSource=self;
    AppDelegate *ud=(AppDelegate *)[UIApplication sharedApplication].delegate;
    NSLog(@"%@",ud.persistentContainer.viewContext);
    context=ud.persistentContainer.viewContext;
    
}
-(void)viewWillAppear:(BOOL)animated{
    NSFetchRequest *fetch=[NSFetchRequest fetchRequestWithEntityName:@"Person"];
    NSError *error;
    array=[context executeFetchRequest:fetch error:&error];
    if (error) {
        NSLog(@"%@",error.localizedDescription);
    }
    else{
        _tblvw.delegate=self;
        _tblvw.dataSource=self;
        [_tblvw reloadData];
    }
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return array.count;
    
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *string=@"CoredataViewCell";
    CoredataViewCell *cell=[tableView dequeueReusableCellWithIdentifier:string];
    if(cell==nil){
        cell=[[CoredataViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:string];
        
    }
    NSManagedObject *obj = [array objectAtIndex:indexPath.row];
    NSArray *arraypath =NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *strPath = arraypath[0];
    NSString *strImgName = [obj valueForKey:@"imgname"];
    NSString *strFullPAth = [strPath stringByAppendingPathComponent:strImgName];
    [cell.cellimgvw sd_setImageWithURL:[NSURL fileURLWithPath:strFullPAth] placeholderImage:[UIImage imageNamed:@"images.png"]];
    cell.showname.text=[obj valueForKey:@"name"];
    cell.showaddress.text=[obj valueForKey:@"address"];
    return cell;
    
}
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        NSMutableArray *muarray=[[NSMutableArray alloc]init];
        muarray=[array mutableCopy];
        NSManagedObject *obj=[array objectAtIndex:indexPath.row];
        [context deleteObject:obj];
        [context save:nil];
        [muarray removeObjectAtIndex:indexPath.row];
        array =[muarray copy];
        [_tblvw reloadData];
    }
}
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return YES - we will be able to delete all rows
    return YES;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSManagedObject *obj=[array objectAtIndex:indexPath.row];
    UPDATEViewController *up=[self.storyboard instantiateViewControllerWithIdentifier:@"UPDATEViewController"];
    up.upOBJ=obj;
    [self.navigationController pushViewController:up animated:YES];
    
    
    
}

@end
