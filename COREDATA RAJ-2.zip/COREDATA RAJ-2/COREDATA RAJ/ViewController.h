//
//  ViewController.h
//  COREDATA RAJ
//
//  Created by Student P_02 on 15/07/17.
//  Copyright © 2017 Felix ITs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate>

@property (weak, nonatomic) IBOutlet UIImageView *imgvw;
@property (weak, nonatomic) IBOutlet UITextField *nametxt;
- (IBAction)imagepickaction:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *Addresstxt;
@property (weak, nonatomic) IBOutlet UITextField *Passwordtxt;
- (IBAction)save:(id)sender;
- (IBAction)DISPLAYDATA:(id)sender;

@end

