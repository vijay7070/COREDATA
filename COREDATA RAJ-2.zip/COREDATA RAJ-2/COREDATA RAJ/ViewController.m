//
//  ViewController.m
//  COREDATA RAJ
//
//  Created by Student P_02 on 15/07/17.
//  Copyright © 2017 Felix ITs. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"
@interface ViewController (){
    NSManagedObjectContext *context;
    BOOL isImgTrue;

}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    isImgTrue = false;
    // Do any additional setup after loading the view, typically from a nib.
    AppDelegate *ud=(AppDelegate *)[UIApplication sharedApplication].delegate;
    NSLog(@"%@",ud.persistentContainer.viewContext);
    context=ud.persistentContainer.viewContext;
    UIImage *img=[UIImage imageNamed:@"images.png"];
    _imgvw.image=img;
    
   
}
//-(void)viewWillAppear:(BOOL)animated{
    
  //  UIImage *img=[UIImage imageNamed:@"images.png"];
    //_imgvw.image=img;
    
//}
-(NSString *)uuid
{
    CFUUIDRef uuidRef = CFUUIDCreate(NULL);
    CFStringRef uuidStringRef = CFUUIDCreateString(NULL, uuidRef);
    CFRelease(uuidRef);
    NSString *strName = [NSString stringWithFormat:@"%@.png", (__bridge_transfer NSString *)uuidStringRef];
    return strName;
}
-(void)save{
    NSEntityDescription *entity=[NSEntityDescription entityForName:@"Person" inManagedObjectContext:context];
    NSManagedObject *obj=[[NSManagedObject alloc]initWithEntity:entity insertIntoManagedObjectContext:context];
   
    [obj setValue:_nametxt.text forKey:@"name"];
    [obj setValue:_Addresstxt.text forKey:@"address"];
    [obj setValue:_Passwordtxt.text forKey:@"password"];
    if (isImgTrue) {
        NSArray *array =NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *strPath = array[0];
        NSData *data = UIImageJPEGRepresentation(_imgvw.image, 1);
        NSString *strName =[self uuid];
        [data writeToFile:[strPath stringByAppendingPathComponent:strName] atomically:YES];
        [obj setValue:strName forKey:@"imgname"];
    }else{
        [obj setValue:@"" forKey:@"imgname"];
    }
    NSError *error;
    [context save:&error];
    if (error) {
        
            UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"ERROR" message:error.localizedDescription preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *action=[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
                [self dismissViewControllerAnimated:YES completion:nil];
                
            }];
            [alert addAction:action];
        [self presentViewController:alert animated:YES completion:nil];

    }else{
       
            UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"SAVED SUCCESSFULLY" message:@"YOUR DATA SAVED SUCCESSFULLY" preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *action=[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
                [self dismissViewControllerAnimated:YES completion:nil];
                
            }];
            [alert addAction:action];
        [self presentViewController:alert animated:YES completion:nil];
        _nametxt.text=@"";
        _Addresstxt.text=@"";
        _Passwordtxt.text=@"";
    }
   
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)save:(id)sender {
    [_nametxt resignFirstResponder];
    [_Addresstxt resignFirstResponder];
    [_Passwordtxt resignFirstResponder];
    if ([_nametxt.text isEqualToString:@""]&&[_Addresstxt.text isEqualToString:@""]&&[_Passwordtxt.text isEqualToString:@""]) {
        UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"ERROR" message:@"Please Don't Leave Blank TextFields" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *action=[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
            [self dismissViewControllerAnimated:YES completion:nil];
        
        }];
        
        [alert addAction:action];
        [self presentViewController:alert animated:YES completion:nil];
    }else{
        [self save];
        UIImage *img=[UIImage imageNamed:@"images.png"];
        _imgvw.image=img;
        
    }
    
    
}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    NSLog(@"%@",info);
    isImgTrue = true;
    UIImage *imge = info[UIImagePickerControllerEditedImage];
    _imgvw.image=imge;
    [self dismissViewControllerAnimated:YES completion:nil];
    
}
- (IBAction)DISPLAYDATA:(id)sender {
}
- (IBAction)imagepickaction:(id)sender {
    UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"BROWSE" message:@"CHOOSE THE OPTION" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action1=[UIAlertAction actionWithTitle:@"CAMERA" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        [self dismissViewControllerAnimated:YES completion:nil];
        UIImagePickerController *picker=[[UIImagePickerController alloc]init];
        picker.delegate=self;
        picker.allowsEditing=YES;
        picker.sourceType=UIImagePickerControllerSourceTypeCamera;
        [self presentViewController:picker animated:YES completion:nil];
    }];
    UIAlertAction *action2=[UIAlertAction actionWithTitle:@"GALLERY" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        [self dismissViewControllerAnimated:YES completion:nil];
        UIImagePickerController *picker=[[UIImagePickerController alloc]init];
        picker.delegate=self;
        picker.allowsEditing=YES;
        picker.sourceType=UIImagePickerControllerSourceTypePhotoLibrary;
        [self presentViewController:picker animated:YES completion:nil];
    }];
    UIAlertAction *action3=[UIAlertAction actionWithTitle:@"CANCEL" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        [self dismissViewControllerAnimated:YES completion:nil];
            }];

    [alert addAction:action1];
    [alert addAction:action2];
    [alert addAction:action3];
    [self presentViewController:alert animated:YES completion:nil];
    

}
@end
